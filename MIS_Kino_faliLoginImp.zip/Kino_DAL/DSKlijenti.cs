﻿namespace Kino_DAL
{
}

namespace Kino_DAL
{


    public partial class DSKlijenti
    {
    }
}
namespace Kino_DAL {
    
    
    public partial class DSKlijenti {
    }
}
