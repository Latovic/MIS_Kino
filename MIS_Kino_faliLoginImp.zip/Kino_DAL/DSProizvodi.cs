﻿namespace Kino_DAL
{


    partial class DSProizvodi
    {
    }
}
