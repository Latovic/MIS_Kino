﻿namespace Kino_DAL
{
}

namespace Kino_DAL
{


    public partial class DSRezervacije
    {
    }
}
namespace Kino_DAL {
    
    
    public partial class DSRezervacije {
    }
}
