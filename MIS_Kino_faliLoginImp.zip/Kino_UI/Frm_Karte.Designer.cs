﻿namespace Kino_UI
{
    partial class Frm_Karte
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_Karte));
            this.txtVrijeme = new System.Windows.Forms.TextBox();
            this.txtDvoranaNaziv = new System.Windows.Forms.TextBox();
            this.txtNazivFilma = new System.Windows.Forms.TextBox();
            this.lblVrijeme = new System.Windows.Forms.Label();
            this.lblDvorana = new System.Windows.Forms.Label();
            this.lblFilm = new System.Windows.Forms.Label();
            this.lblKarte = new System.Windows.Forms.Label();
            this.txtCijena = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDrzava = new System.Windows.Forms.TextBox();
            this.lblDrzava = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtVrijeme
            // 
            this.txtVrijeme.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtVrijeme.Location = new System.Drawing.Point(82, 119);
            this.txtVrijeme.Name = "txtVrijeme";
            this.txtVrijeme.ReadOnly = true;
            this.txtVrijeme.Size = new System.Drawing.Size(204, 20);
            this.txtVrijeme.TabIndex = 19;
            // 
            // txtDvoranaNaziv
            // 
            this.txtDvoranaNaziv.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtDvoranaNaziv.Location = new System.Drawing.Point(82, 93);
            this.txtDvoranaNaziv.Name = "txtDvoranaNaziv";
            this.txtDvoranaNaziv.ReadOnly = true;
            this.txtDvoranaNaziv.Size = new System.Drawing.Size(204, 20);
            this.txtDvoranaNaziv.TabIndex = 18;
            // 
            // txtNazivFilma
            // 
            this.txtNazivFilma.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtNazivFilma.Location = new System.Drawing.Point(82, 42);
            this.txtNazivFilma.Name = "txtNazivFilma";
            this.txtNazivFilma.ReadOnly = true;
            this.txtNazivFilma.Size = new System.Drawing.Size(204, 20);
            this.txtNazivFilma.TabIndex = 17;
            // 
            // lblVrijeme
            // 
            this.lblVrijeme.AutoSize = true;
            this.lblVrijeme.Location = new System.Drawing.Point(19, 122);
            this.lblVrijeme.Name = "lblVrijeme";
            this.lblVrijeme.Size = new System.Drawing.Size(44, 13);
            this.lblVrijeme.TabIndex = 16;
            this.lblVrijeme.Text = "Vrijeme:";
            // 
            // lblDvorana
            // 
            this.lblDvorana.AutoSize = true;
            this.lblDvorana.Location = new System.Drawing.Point(19, 96);
            this.lblDvorana.Name = "lblDvorana";
            this.lblDvorana.Size = new System.Drawing.Size(51, 13);
            this.lblDvorana.TabIndex = 15;
            this.lblDvorana.Text = "Dvorana:";
            // 
            // lblFilm
            // 
            this.lblFilm.AutoSize = true;
            this.lblFilm.Location = new System.Drawing.Point(19, 45);
            this.lblFilm.Name = "lblFilm";
            this.lblFilm.Size = new System.Drawing.Size(28, 13);
            this.lblFilm.TabIndex = 14;
            this.lblFilm.Text = "Film:";
            // 
            // lblKarte
            // 
            this.lblKarte.AutoSize = true;
            this.lblKarte.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblKarte.Location = new System.Drawing.Point(19, 9);
            this.lblKarte.Name = "lblKarte";
            this.lblKarte.Size = new System.Drawing.Size(37, 13);
            this.lblKarte.TabIndex = 13;
            this.lblKarte.Text = "Karte";
            // 
            // txtCijena
            // 
            this.txtCijena.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtCijena.Location = new System.Drawing.Point(82, 145);
            this.txtCijena.Name = "txtCijena";
            this.txtCijena.ReadOnly = true;
            this.txtCijena.Size = new System.Drawing.Size(204, 20);
            this.txtCijena.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 148);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 13);
            this.label1.TabIndex = 20;
            this.label1.Text = "Cijena:";
            // 
            // txtDrzava
            // 
            this.txtDrzava.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.txtDrzava.Location = new System.Drawing.Point(82, 67);
            this.txtDrzava.Name = "txtDrzava";
            this.txtDrzava.ReadOnly = true;
            this.txtDrzava.Size = new System.Drawing.Size(204, 20);
            this.txtDrzava.TabIndex = 23;
            // 
            // lblDrzava
            // 
            this.lblDrzava.AutoSize = true;
            this.lblDrzava.Location = new System.Drawing.Point(19, 70);
            this.lblDrzava.Name = "lblDrzava";
            this.lblDrzava.Size = new System.Drawing.Size(44, 13);
            this.lblDrzava.TabIndex = 22;
            this.lblDrzava.Text = "Država:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(211, 172);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 24;
            this.button1.Text = "Print";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Frm_Karte
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(308, 207);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtDrzava);
            this.Controls.Add(this.lblDrzava);
            this.Controls.Add(this.txtCijena);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtVrijeme);
            this.Controls.Add(this.txtDvoranaNaziv);
            this.Controls.Add(this.txtNazivFilma);
            this.Controls.Add(this.lblVrijeme);
            this.Controls.Add(this.lblDvorana);
            this.Controls.Add(this.lblFilm);
            this.Controls.Add(this.lblKarte);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Frm_Karte";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Klijenti";
            this.Load += new System.EventHandler(this.Frm_Karte_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtVrijeme;
        private System.Windows.Forms.TextBox txtDvoranaNaziv;
        private System.Windows.Forms.TextBox txtNazivFilma;
        private System.Windows.Forms.Label lblVrijeme;
        private System.Windows.Forms.Label lblDvorana;
        private System.Windows.Forms.Label lblFilm;
        private System.Windows.Forms.Label lblKarte;
        private System.Windows.Forms.TextBox txtCijena;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDrzava;
        private System.Windows.Forms.Label lblDrzava;
        private System.Windows.Forms.Button button1;
    }
}